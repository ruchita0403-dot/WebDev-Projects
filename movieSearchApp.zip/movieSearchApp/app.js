var express=require("express");
var app=express();
var request=require("axios");

app.set("view engine", "ejs");
app.engine('ejs', require('ejs').__express);

app.get("/",function(req,res){
	res.render("home");
});

app.get("/results",function(req,res){
	var mvename=req.query.movieName;
	var url= 'http://www.omdbapi.com/?s='+mvename+'&apikey=thewdb';
	request.get(url)
	  .then(function (response) {
		var idata=response.data;
		res.render("results",{data:idata});
	  })
	  .catch(function (error) {
		res.send("an error has occur!!");
	  })
	  .finally(function () {
		
	  });	
});	

app.listen(3000,process.env.IP,function(){
	console.log("movie app has started!!");
})